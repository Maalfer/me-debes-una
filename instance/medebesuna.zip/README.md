# Deudas App

Una aplicación web en Flask para gestionar deudas entre dos personas.

## Cómo usar

1. Instala las dependencias:
```bash
pip install -r requirements.txt
```

2. Ejecuta la app:
```bash
python app.py
```

<img width="985" height="908" alt="image" src="https://github.com/user-attachments/assets/e7c67a96-b556-4185-bf70-f363686657a8" />
